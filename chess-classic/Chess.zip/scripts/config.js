var _data = {
	board: {
		x: 158,
		y: 323,
	},
	size: 58,
	depth: 1,
	sound: true,
	game_mode: 'local',
}